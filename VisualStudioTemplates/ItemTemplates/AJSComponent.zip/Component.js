﻿define(['knockout', 'Application'], function (ko, Application)
{
    var $safeitemname$ = function ()
    {
        var self = this;

        self.Activated.On(function ()
        {
        
        });

        self.Loaded.On(function ()
        {

        });
    };

    return $safeitemname$;
});